package com.exemple.ktgk_listview;
public class User {
    String name,lastMessage, lasMsgTime, wei, country, dob,hei,clb,year,team,match,goal;
    int imageId;
    public User(String name, String lastMessage, String lasMsgTime, String wei, String country, String dob, String hei, String clb, String year, String team, String match, String goal, int imageId) {
        this.name = name;
        this.lastMessage = lastMessage;
        this.lasMsgTime = lasMsgTime;
        this.wei = wei;
        this.country = country;
        this.dob = dob;
        this.hei = hei;
        this.clb = clb;
        this.year = year;
        this.team = team;
        this.match = match;
        this.goal = goal;
        this.imageId = imageId;
    }
}

